package com.pawan.restapi.controller;


import com.pawan.restapi.dto.StudentDto;
import com.pawan.restapi.entity.Student;
import com.pawan.restapi.repository.StudentRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class StudentController {
    private final StudentRepository studentRepositoy;
    public StudentController(StudentRepository studentRepositoy){
        this.studentRepositoy=studentRepositoy;
    }

    @GetMapping("/student")
    public List<Student> getStudent(){
        return studentRepositoy.findAll();
    }


    @GetMapping("/student/{id}")
    public Student getStudentById(){
        return new Student(8071L, "Pawan", "pawan.kumar@gmail.com");
    }



}
